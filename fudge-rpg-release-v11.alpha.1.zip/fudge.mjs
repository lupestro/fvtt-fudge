/* Extend the base Actor class to implement additional system-specific logic. */


class ActorFudge extends Actor {

  async findAttributes(id) {
    let result = game.collections.get("Item").find((item) => item._id === id);
    if (!result) {
      // Find which pack (if any) the configured id is in
      const pack = game.packs.find((aPack) => aPack.index.find((item) => item._id === id));
      if (pack) {
        result = await pack.getDocument(id);
      }
    }
    return result;
  }
  
  /** @inheritdoc */
  async _preCreate(data, options, userId) {
    await super._preCreate(data, options, userId);
    this.updateSource({
      "system.unspent.skilllevels": game.settings.get("fudge-rpg", "initialskilllevels"),
      "system.unspent.attrlevels": game.settings.get("fudge-rpg", "initialattrlevels"),
      "system.unspent.gifts": game.settings.get("fudge-rpg", "initialgifts")
    });
    const attributeset = await this.findAttributes(game.settings.get("fudge-rpg", "defaultattributeset"));
    if (attributeset) {
      await this.items.update([attributeset]);
    }
  }

  /** @inheritdoc */
  /* 
   * This gets called before the new item gets created, so for unique items, we can remove the old one first.
   * Also tracks gifts and faults against the allotted numbers, but doesn't enforce limits.
   */
  async _onCreateEmbeddedDocuments(embeddedName, items, ...args) {
    const allOldUniqueIds = [];
    let giftCount = 0;
    let faultCount = 0;

    /*
     * Ensure replacement rather than addition of attribute sets and trait level sets by removing old before adding new
     * Determine how many gifts and faults are being added
     */
    for (const item of items) {
      if (item.type === "attributeset") {
        const currentsets = this.items.filter((attrsetItem) => attrsetItem.type === "attributeset");
        const oldids = currentsets
          .filter((attrset) => attrset.id !== item.id)
          .map((attrset) => attrset.id);
        allOldUniqueIds.push(...oldids);
      } else if (item.type === "traitlevelset") {
        const currentsets = this.items.filter((traitsetItem) => traitsetItem.type === "traitlevelset");
        const oldids = currentsets
          .filter((attrset) => attrset.id !== item.id)
          .map((attrset) => attrset.id);
          allOldUniqueIds.push(...oldids);
      } else if (item.type === "gift") {
        giftCount += 1;
      } else if (item.type === "fault") {
        faultCount += 1;
      }
    }
    
    /* 
     * Now we're out of the loop, do the business end of things - 
     * * Apply the gifts against the allotment, and use the faults to augment the allotment
     * * Remove any existing sets of trait levels and attribute sets applied to the character
     */
    if (giftCount > 0) {
      await this.update({"system.unspent.gifts": this.system.unspent.gifts - giftCount});
    }
    if (faultCount > 0) {
      await this.update({"system.unspent.faults": this.system.unspent.faults + faultCount});
    }
    if (allOldUniqueIds.length > 0) {
      await this.deleteEmbeddedDocuments("Item", allOldUniqueIds);
    }
    await super._onCreateEmbeddedDocuments(embeddedName, items, ...args);
  }
}

/**
 * Extend the base Item class to implement additional system-specific logic.
 */
 class ItemFudge extends Item {
    // Except we don't have any additional document-level logic yet ... but perhaps we will ...
 }

class TraitRoll extends Roll {
  levelname(levelset) {
    const levelsetitem = levelset.find((levelInSet) => this.total === levelInSet.value);
    if (levelsetitem) {
      return levelsetitem.name;
    }
    if (this.total > 0) {
      const levelsetmax = levelset.reduce((prevItem, currItem) => {
        if (prevItem) {
          return currItem.value > prevItem.value ? currItem : prevItem;
        }
        return currItem;
      }, null);
      return `${levelsetmax.name} + ${this.total - levelsetmax.value}`;
    }
    const levelsetmin = levelset.reduce((prevItem, currItem) => {
      if (prevItem) {
        return currItem.value < prevItem.value ? currItem : prevItem;
      }
      return currItem;
    }, null);
    return `${levelsetmin.name} - ${levelsetmin.value - this.total}`;
  }

  async render(options) {
    const LEVELSET = [
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Superb"), value: +3}, // eslint-disable-line no-magic-numbers
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Great"), value: +2}, // eslint-disable-line no-magic-numbers
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Good"), value: +1},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Fair"), value: 0},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Mediocre"), value: -1},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Poor"), value: -2},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Terrible"), value: -3}
    ];
    if (game.settings.get("fudge-rpg", "traitlevels") === "extended") {
      LEVELSET.unshift(
        {name: game.i18n.localize("FUDGERPG.TraitLevel.Legendary"), value: +5}, // eslint-disable-line no-magic-numbers
        {name: game.i18n.localize("FUDGERPG.TraitLevel.Heroic"), value: +4} // eslint-disable-line no-magic-numbers
      );
    }
    const isPrivate = options.isPrivate ?? false;
    const template = options.template ?? this.constructor.CHAT_TEMPLATE;
    const {flavor} = options;
    if ( !this._evaluated ) {
      await this.evaluate({async: true});
    }
    const chatData = {
      formula: isPrivate ? "???" : this._formula,
      flavor: isPrivate ? null : flavor,
      user: game.user.id,
      tooltip: isPrivate ? "" : await super.getTooltip(),
      total: `${this.levelname(LEVELSET)} (${this.total})`
    };
    return renderTemplate(template, chatData);
  }
}

const WOUND_MODIFIER_NEARDEATH = -10;
const WOUND_MODIFIER_INCAPACITATED = -5;
const WOUND_MODIFIER_VERYHURT = -2;
const WOUND_MODIFIER_HURT = -1;
const WOUND_MODIFIER_OK = 0;
const SKILL_LEVEL_POOR = -2;
const LEVEL_TRADES = {
  "skill-points:attribute-points": "3/1",
  "skill-points:gift-points": "6/1",
  "skill-points:fault-points":"-6/1",
  "attribute-points:skill-points":"1/3",
  "attribute-points:gift-points": "2/1",
  "attribute-points:fault-points": "-2/1",
  "gift-points:skill-points": "1/6",
  "gift-points:attribute-points": "1/2",
  "gift-points:fault-points": "-1/1",
  "fault-points:skill-points":"1/-6",
  "fault-points:attribute-points":"1/-2",
  "fault-points:gift-points":"1/-1",
};
const TRADE_PROPS = {
  "attribute-points": "system.unspent.attrlevels",
  "gift-points": "system.unspent.gifts",
  "skill-points": "system.unspent.skilllevels",
  "fault-points": "system.unspent.faults",
};

/**
 * Extend the base ActorSheet class to implement our character sheet.
 */

class ActorSheetFudgeMajor extends ActorSheet {

  // -------- Overrides --------

  get template() {
    return "systems/fudge-rpg/templates/major-actor.hbs";
  }

  static get defaultOptions() {
    let newOptions = super.defaultOptions;
    newOptions.dragDrop.push({dragSelector: ".occ-count", dropSelector: ".occ-count"});
    return newOptions;
  }
  /*
   * The context data provided by getData is the data made available to the template.
   * It is not available via "this", so it cannot be used in event listeners.
   */
  async getData(options) {
    const context = super.getData(options);
    const {actor} = context;

    /*
     * A constant is being used here as a temporary measure. 
     * What should happen eventually: 
     * * the actor defines the number of boxes at each level according to a game rule.
     * * this method derives the following structure from that data and the actors wounds.
     * Since we're not touching the actor yet and haven't defined a mechanism for customization
     * we'll use a default constant set here for now.
     */
    context.woundlevels = {
      scratch: [false, false, false],
      hurt: [false],
      veryhurt: [false],
      incapacitated: [false],
      neardeath: [false]
    };
    for (const level in context.actor.system.wounds) {
      if ({}.hasOwnProperty.call(context.actor.system.wounds, level)) {
        for (let box = 0; box < context.woundlevels[level].length; box += 1) {
          context.woundlevels[level][box] = box < context.actor.system.wounds[level];
        }
      }
    }
    context.attributeset = this.object.items.find((item) => item.type === "attributeset");
    context.traitlevels = [
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Superb"), value: +3}, // eslint-disable-line no-magic-numbers
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Great"), value: +2}, // eslint-disable-line no-magic-numbers
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Good"), value: +1},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Fair"), value: 0},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Mediocre"), value: -1},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Poor"), value: -2},
      {name: game.i18n.localize("FUDGERPG.TraitLevel.Terrible"), value: -3}
    ];
    if (game.settings.get("fudge-rpg", "traitlevels") === "extended") {
      context.traitlevels.unshift(
        {name: game.i18n.localize("FUDGERPG.TraitLevel.Legendary"), value: +5}, // eslint-disable-line no-magic-numbers
        {name: game.i18n.localize("FUDGERPG.TraitLevel.Heroic"), value: +4} // eslint-disable-line no-magic-numbers
      );
    }
    context.notesHTML = await TextEditor.enrichHTML(actor.system.notes, {async: true});
  
    return context;
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find(".traitselect").change(this._onLevelChange.bind(this));
    html.find(".woundbox").change(this._onWoundsChange.bind(this));
    html.find("#charname").change(this._onCharacterNameChange.bind(this));
    html.find("#fp").change(this._onScoreChange.bind(this));
    html.find("#ep").change(this._onScoreChange.bind(this));
    html.find("#attribute-points").change(this._onAttributePointsChange.bind(this));
    html.find("#gift-points").change(this._onGiftPointsChange.bind(this));
    html.find("#skill-points").change(this._onSkillPointsChange.bind(this));
    html.find("#fault-points").change(this._onFaultPointsChange.bind(this));
    html.find(".delete-button").click(this._onDeleteClick.bind(this));
    html.find(".roll-button").click(this._onRollClick.bind(this));
    html.find(".itemname").click(this._onSelectItem.bind(this));
  }

  _onDragStart(event) {
    if (event.currentTarget.classList.contains("occ-count")) {
      event.dataTransfer.setData("text/plain", JSON.stringify({
        from: event.currentTarget.id
      }));
    } else {
      super._onDragStart(event);
    }
  }
  _onDrop(event) {
    if (event.toElement.classList.contains("occ-count")) {
      const data = TextEditor.getDragEventData(event);
      if (data.from) {
        const srcElement = this.form.querySelector(`#${data.from}`);
        this._tradePoints (srcElement, event.toElement);
      }
    } else {
      super._onDrop(event);
    }
  }

  // -------- Utility methods --------

  getTraitModifier(type, id) {
    let modifier = 0;
    let traitName = "";
    if (type === "attr") {
      const attrset = this.object.items.find( (item) => item.type === "attributeset" );
      modifier = attrset.system.attributes[parseInt(id, 10)].level;
      traitName = attrset.system.attributes[parseInt(id, 10)].name;
    } else if (type === "skill") {
      const skill = this.object.items.get(id);
      modifier = skill.system.level;
      traitName = skill.name;
    }
    return {modifier, traitName};
  }

  get woundModifier () {
    if (this.object.system.wounds.neardeath > 0) {
      return WOUND_MODIFIER_NEARDEATH;
    } else if (this.object.system.wounds.incapacitated > 0) {
      return WOUND_MODIFIER_INCAPACITATED;
    } else if (this.object.system.wounds.veryhurt > 0) {
      return WOUND_MODIFIER_VERYHURT;
    } else if (this.object.system.wounds.hurt > 0) {
      return WOUND_MODIFIER_HURT;
    } 
    return WOUND_MODIFIER_OK;
  }

  // -------- Event Listeners --------

  async _onLevelChange(event) {
    const control = event.target;
    const level = parseInt(control.value, 10);
    const [prefix, id] = control.id.split("-");
    if (prefix === "attr") {
      const attrIndex = parseInt(id, 10);
      const attrset = this.object.items.find((item) => item.type === "attributeset" );
      const oldLevel = attrset.system.attributes[attrIndex].level;
      const newAttributes = foundry.utils.deepClone(attrset.system.attributes);
      newAttributes[attrIndex].level = level;
      await attrset.update({"system.attributes": newAttributes});
      await this.object.update({
        "system.unspent.attrlevels": this.object.system.unspent.attrlevels - (level - oldLevel)
      });
    } else if (prefix === "sel") {
      const skill = this.object.items.get(id);
      const oldLevel = skill.system.level;
      await skill.update({"system.level": level});
      await this.object.update({
        "system.unspent.skilllevels": this.object.system.unspent.skilllevels - (level - oldLevel)
      });
    } 
  }

  async _onWoundsChange(event) {
    const control = event.target;
    const [levelToCheck] = control.id.split("-");
    let newCount = 0;
    for (const box of this.form) {
      if (box.classList.contains("woundbox") && box.id.startsWith(levelToCheck)) {
          newCount += box.checked ? 1 : 0;
      }
    }
    const updates = {};
    updates[`system.wounds.${levelToCheck}`] = newCount;
    await this.object.update(updates);
  }
  
  async _onCharacterNameChange(event) {
    await this.object.update({name: event.target.value.trim()});
  }
  
  async _onAttributePointsChange(event) {
    const result = parseInt(event.target.value, 10);
    if (!isNaN(result)) {
      await this.object.update({"system.unspent.attrlevels": result});
    }
  }

  async _onSkillPointsChange(event) {
    const result = parseInt(event.target.value, 10);
    if (!isNaN(result)) {
      await this.object.update({"system.unspent.skilllevels": result});
    }
  }

  async _onGiftPointsChange(event) {
    const result = parseInt(event.target.value, 10);
    if (!isNaN(result)) {
      await this.object.update({"system.unspent.gifts": result});
    }
  }

  async _onFaultPointsChange(event) {
    const result = parseInt(event.target.value, 10);
    if (!isNaN(result)) {
      await this.object.update({"system.unspent.faults": result});
    }
  }

  async _onScoreChange(event) {
    const result = parseInt(event.target.value, 10);
    const score = event.target.id;
    if (isNaN(result)) {
      event.target.value = this.object.system[score].toString();
    } else {
      const updates = {};
      updates[`system.${score}`] = result;
      await this.object.update(updates);  
    }
  }

  async _onDeleteClick(event) {
    const [prefix, id] = event.target.id.split("-");
    if (prefix === "del") {
      const item = this.object.items.get(id);
      if (item.type === "skill") {
        await this.object.update({
          "system.unspent.skilllevels":
            this.object.system.unspent.skilllevels - (SKILL_LEVEL_POOR - item.system.level)
        });
      }
      if (item.type === "gift") {
        await this.object.update({"system.unspent.gifts": this.object.system.unspent.gifts + 1});
      }
      if (item.type === "fault") {
        await this.object.update({"system.unspent.faults": this.object.system.unspent.faults - 1});
      }
      await this.object.deleteEmbeddedDocuments("Item", [id]);
    }
  }

  async _onRollClick(event) {
    const [prefix, type, id] = event.target.id.split("-");
    if (prefix === "roll") {
      if (this.woundModifier === WOUND_MODIFIER_NEARDEATH) {
        await Dialog.prompt({
          title: game.i18n.localize("FUDGERPG.NoActionsTitle"),
          content: game.i18n.localize("FUDGERPG.NoActionsNearDeath"),
          label: "OK"
         });
      } else if (this.woundModifier === WOUND_MODIFIER_INCAPACITATED) {
        await Dialog.prompt({
          title: game.i18n.localize("FUDGERPG.NoActionsTitle"),
          content: game.i18n.localize("FUDGERPG.NoActionsIncapacitated"),
          label: "OK"
         });
      } else {
        const traitModifier = this.getTraitModifier(type, id);

        const roll = new TraitRoll("4df + (@levelmod) + (@woundmod)", {
          levelmod: traitModifier.modifier, 
          woundmod: this.woundModifier
        });
        await roll.evaluate({async: true});
        await roll.toMessage({
          speaker: ChatMessage.getSpeaker({actor: this.actor}),
          flavor: game.i18n.localize("FUDGERPG.Rolling").replace("{traitname}", traitModifier.traitName)
        });
      }
    }
  }

  _onSelectItem(event) {
    const itemId = event.target.getAttribute("data-id");
    const item = this.object.items.get(itemId);
    item.sheet.render(true);
  }

  _tradePoints(fromElement, toElement) {
    if (fromElement.id !== toElement.id) {
      if (LEVEL_TRADES[`${fromElement.id}:${toElement.id}`]) {
        const trade = LEVEL_TRADES[`${fromElement.id}:${toElement.id}`]
          .split('/')
          .map(item => parseFloat(item));
        const fromValue = parseFloat(fromElement.value);
        const toValue = parseFloat(toElement.value);
        if (!isNaN(fromValue) && !isNaN(toValue)) {
          if (fromValue >= trade[0]) {
            let updatedValues = {};
            updatedValues[TRADE_PROPS[fromElement.id]] = fromValue - trade[0];
            updatedValues[TRADE_PROPS[toElement.id]] = toValue + trade[1];
            this.object.update(updatedValues);
          } else {
            console.log(`Not enough points for trade: ${fromElement.id} -> ${toElement.id}`);
          }
        }
      }  
    } else {
      console.log (`Dragged to self: ${toElement.id}`);
    }
  }
}

class ItemSheetFudge extends ItemSheet {
  get template() {
    return "systems/fudge-rpg/templates/item.hbs";
  }

  /** @override */
  async getData(options) {
    const context = await super.getData(options);
    const {item} = context;
    foundry.utils.mergeObject(context, {
      descriptionHTML: await TextEditor.enrichHTML(item.system.description, {async: true})
    });
    if (item.type === "attributeset") {
      context.attributelist = item.system.attributes.map((attribute) => attribute.name).join("\n");
    }
    return context;
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find("#itemname").change(this._onNameChange.bind(this));
    html.find("#attributes").change(this._onAttributesChange.bind(this));
    html.find("#muscleweapon").change(this._onMuscleWeaponAttributeChange.bind(this));
    html.find("#damagecapacity").change(this._onDamageCapacityAttributeChange.bind(this));
    html.find("#skillgroup").change(this._onSkillGroupChange.bind(this));
    html.find("#skillgroup2").change(this._onSkillGroup2Change.bind(this));
    html.find("#odf").change(this._onNumberFieldChange.bind(this));
    html.find("#ddf").change(this._onNumberFieldChange.bind(this));
    html.find("#quantity").change(this._onNumberFieldChange.bind(this));
  }

  async _onNameChange(event) {
    await this.object.update({name: event.target.value.trim()});
  }

  async _onAttributesChange(event) {
    const newAttributeNames = event.target.value.split("\n");
    const newAttributes = [];
    for (const name of newAttributeNames) {
      const cleanName = name.trim();
      if ( cleanName !== "") {
        const attribute = {name: cleanName, level: 0};
        const oldAttribute = this.object.system.attributes
          .find( (attr) => attr.name.toLowerCase() === cleanName.toLowerCase());
        if (oldAttribute) {
          attribute.level = oldAttribute.level;
        }
        newAttributes.push(attribute);
      }
    }
    await this.object.update( {"system.attributes": newAttributes});
  }

  async _onMuscleWeaponAttributeChange(event) {
    await this.object.update( {"system.muscleweapon": event.target.value});
  }

  async _onDamageCapacityAttributeChange(event) {
    await this.object.update( {"system.damagecap": event.target.value});
  }
  
  async _onSkillGroupChange(event) {
    await this.object.update({"system.group": event.target.value.trim()});
  }

  async _onSkillGroup2Change(event) {
    await this.object.update({"system.group2": event.target.value.trim()});
  }
  
  async _onNumberFieldChange(event) {
    const result = parseInt(event.target.value, 10);
    const score = event.target.id;
    if (isNaN(result)) {
      event.target.value = this.object.system[score].toString();
    } else {
      const updates = {};
      updates[`system.${score}`] = result;
      await this.object.update(updates);  
    }
  }
}

CONFIG.Actor.documentClass = ActorFudge;
CONFIG.Item.documentClass = ItemFudge;
const FANTASY_FUDGE_ATTRIBUTES_FROM_COMPENDIUM = "RqHSqHtArZYVOJap";

// eslint-disable-next-line no-unused-vars
const loadPartials = function(partials) {
  const paths = {};
  for ( const path of partials ) {
    paths[path.replace(".hbs", ".html")] = path;
    paths[`fudge.${path.split("/").pop().replace(".hbs", "")}`] = path;
  }

  return loadTemplates(paths);
};

const displayWithSign = function(num) {
  return num > 0 ? `+${num}` : num.toString();
};

const availableAttributes = () => {
  const result = {};
  game.collections.get("Item")
    .filter((item) => item.type === "attributeset")
    .forEach( (item) => { 
      result[item._id] = `${item.name} (Items)`;
    });
  game.packs.forEach((pack) => {
    if (pack.metadata.type === "Item") {
      pack.index.filter((item) => item.type === "attributeset")
      .forEach( (item) => {
        result[item._id] = `${item.name} (${pack.metadata.label})`;
      });
    }
  });
  return result;
};
/**
 * We have to register these at ready, because they require
 * looking at items and loaded compendia for attribute sets.
 */
const registerResourceDependentSystemSettings = function() {
  game.settings.register("fudge-rpg", "defaultattributeset", {
    name: "FUDGERPG.DefaultAttributeSet",
    hint: "FUDGERPG.DefaultAttributeSetHint",
    scope: "world",
    config: true,
    default: FANTASY_FUDGE_ATTRIBUTES_FROM_COMPENDIUM,
    type: String,
    choices: availableAttributes()
  });
};

/**
 * We register everything that we can at init. This is especially
 * important for the trait levels because they are used in
 * restoring the chat history.
 */
const registerIndependentSystemSettings = function() {
  game.settings.register("fudge-rpg", "traitlevels", {
    name: "FUDGERPG.TraitLevels",
    hint: "FUDGERPG.TraitLevelsHint",
    scope: "world",
    config: true,
    default: "standard",
    type: String,
    choices: {
      standard: "FUDGERPG.TraitLevelsStandard",
      extended: "FUDGERPG.TraitLevelsExtended"
    }
  });
  
  game.settings.register("fudge-rpg", "initialattrlevels", {
    name: "FUDGERPG.InitialAttrLevels",
    hint: "FUDGERPG.InitialAttrLevelsHint",
    scope: "world",
    config: true,
    default: 3,
    type: Number
  });
  game.settings.register("fudge-rpg", "initialskilllevels", {
    name: "FUDGERPG.InitialSkillLevels",
    hint: "FUDGERPG.InitialSkillLevelsHint",
    scope: "world",
    config: true,
    default: 20,
    type: Number
  });
  game.settings.register("fudge-rpg", "initialgifts", {
    name: "FUDGERPG.InitialGifts",
    hint: "FUDGERPG.InitialGiftsHint",
    scope: "world",
    config: true,
    default: 2,
    type: Number
  });

};

Hooks.once("ready", async function() {
  if (!game.user.getFlag("fudge-rpg", "visited")) {
    await Dialog.prompt({
      title: game.i18n.localize("FUDGERPG.AboutFudge.Title"),
      content: game.i18n.localize("FUDGERPG.AboutFudge.LegalNotice"),
      label: "OK"
    });
    game.user.setFlag("fudge-rpg", "visited", true);
  }
  registerResourceDependentSystemSettings();
});

Hooks.once("init", function() {
  CONFIG.Dice.rolls.push(TraitRoll);
 
  Actors.unregisterSheet("core", ActorFudge);
  Actors.registerSheet("fudge-rpg", ActorSheetFudgeMajor, {
    types: ["major"],
    makeDefault: true,
    label: "FUDGERPG.SheetClassCharacter"
  });
  Items.unregisterSheet("core", ItemFudge);
  Items.registerSheet("fudge-rpg", ItemSheetFudge, {
    types: ["attributeset", "skill", "gift", "fault", "equipment"],
    makeDefault: true,
    label: "FUDGERPG.SheetClassItem"
  });
Handlebars.registerHelper({displayWithSign});
registerIndependentSystemSettings();
loadPartials([]);
  //   "systems/fudge-rpg/templates/partials/traitlevel-selector.hbs"
});
//# sourceMappingURL=fudge-compiled.mjs.map
